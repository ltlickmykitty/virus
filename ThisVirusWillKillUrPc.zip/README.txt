# Memz-2.8.1
Memz Virus Recreated v2.8.1
Main Credit Goes to original MEMZ Virus: https://github.com/Leurak/MEMZ
When you use this program I am not responsible for any: Hardware, Graphics, Booting issues that happen to your computer
This Program is intended to be used as a prank, USE WITH CAUTION!!!!
May cause internal hardware issues.
Whatever happens to your pc or your friends pc is not my fault.
Last of all, have fun with this program.